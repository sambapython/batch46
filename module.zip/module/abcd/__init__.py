print "init"
'''
import file1
import file2
'''