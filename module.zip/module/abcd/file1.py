print "file1"
def fun():
	print "this is fun in file1"

def main():
	"""
	statements required specific to this file
	"""
if __name__ == "__main__":
	main()