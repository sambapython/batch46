print "file2"
def fun():
	print "this is fun in file2"




def main():
	"""
	statements required specific to this file
	"""
if __name__ == "__main__":
	main()