a=10
b=20
def fun():
	print "this is fun in f2"