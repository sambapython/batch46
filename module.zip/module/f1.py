a=10
b=20
def fun():
	print "this is fun in f1"

if __name__ == "__main__":
	c=1000
	print "this is f1 in pwd"
	print "name:",__name__
	print "other statements"
	fun()
	print "f1 ended"