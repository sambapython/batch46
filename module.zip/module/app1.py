'''
import abcd
abcd.file2.fun()
'''
from abcd import file2
file2.fun()